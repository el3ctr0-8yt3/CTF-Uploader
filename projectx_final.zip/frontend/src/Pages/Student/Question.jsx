import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { apiUrl } from "../../config";

const Question = () => {
    const [question, setQuestion] = useState({});
    const [results, setResults] = useState(null);
    const { uuid } = useParams();
    const [loading, setLoading] = useState(false);

    const fetchQuestion = async () => {
        const response = await fetch(`${apiUrl}/question/${uuid}`);
        const data = await response.json();
        setQuestion(data);
    };

    const submissionHandler = async () => {
        const code = document.getElementById("code").value;
        setResults(null);
        setLoading(true);
        const response = await fetch(`${apiUrl}/submission`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                question_uuid: uuid,
                code: code,
            }),
        });
        const data = await response.json();
        setLoading(false);
        setResults(data);
        console.log(data);
    };

    useEffect(() => {
        fetchQuestion();
    }, []);

    return (
        <div className="ml-8 custom-box-width">
            <div className="flex justify-between items-center flex-row">
                <div className="text-2xl font-semibold text-white my-8">
                    {question.title}
                </div>
                <div className="text-xl font-medium text-white my-8">
                    Score: {question.question_score}
                </div>
            </div>
            <div className="text-lg font-normal bg-white p-4 rounded-lg">
                <span className="font-semibold">Description: </span>
                {question.description} <br />
                <span className="font-semibold">Testcase Count: </span>
                {question.testcase_count} <br />
                <span className="font-semibold">Language: </span>
                {question.language}
            </div>
            <div className="text-lg font-normal bg-white p-4 rounded-lg mt-4">
                <span className="font-semibold">Code:</span> <br />
                <textarea
                    id="code"
                    className="w-full border-2 border-black p-2 rounded-lg"
                    rows={10}
                />
            </div>
            <div className="flex justify-between items-center flex-row my-4">
                <button
                    className="bg-green-500 text-white p-2 w-24 font-semibold rounded-lg"
                    onClick={submissionHandler}
                >
                    Submit
                </button>
                <Link to="/student/library">
                    <button className="bg-red-500 text-white p-2 w-24 font-semibold rounded-lg">
                        Cancel
                    </button>
                </Link>
            </div>
            {loading && (
                <div className="text-lg font-normal bg-white p-4 rounded-lg mt-8">
                    Loading...
                </div>
            )}
            {results && (
                <div className="text-lg font-normal bg-white p-4 rounded-lg mt-8">
                    {/* Map over the results array and show status.description*/}
                    {results.map((result, index) => (
                        <div key={index}>
                            <span className="font-semibold">
                                Testcase {index + 1}:
                            </span>{" "}
                            {result.status.description}
                            {result.status.description ===
                                "Compilation Error" && (
                                <>
                                    <br />
                                    {atob(result.compile_output)}
                                </>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default Question;
