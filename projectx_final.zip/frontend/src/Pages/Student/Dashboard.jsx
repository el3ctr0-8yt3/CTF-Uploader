const Dashboard = () => {
    return (
        <div>
            <h1 className="text-2xl font-semibold dark:text-white m-8">
                Student Dashboard
            </h1>
        </div>
    );
};

export default Dashboard;
