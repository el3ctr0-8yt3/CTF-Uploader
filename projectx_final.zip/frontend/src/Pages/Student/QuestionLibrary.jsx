import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { apiUrl } from "../../config";

const QuestionLibrary = () => {
    const [questions, setQuestions] = useState([]);

    const fetchQuestions = async () => {
        const response = await fetch(`${apiUrl}/questions`);
        const data = await response.json();
        setQuestions(data);
    };

    useEffect(() => {
        fetchQuestions();
    }, []);

    return (
        <div className="ml-8">
            <h1 className="text-2xl font-semibold dark:text-white my-8">
                Question Library
            </h1>

            {questions.length === 0 && (
                <p className="mt-8 text-lg font-semibold text-white">
                    Library is empty.
                </p>
            )}

            <div className="mt-8 custom-box-width">
                {questions.map((question, index) => (
                    <div
                        key={index}
                        className="my-4 p-4 bg-dark-p2 rounded-lg font-semibold text-black flex justify-between flex-row items-center"
                    >
                        <p className="inline">{question.title}</p>
                        <Link to={`/student/question/${question.uuid}`}>
                            <button className="bg-blue-500 hover:bg-blue-700 text-white text-xl font-bold w-10 h-10 rounded-full inline">
                                <i className="fas fa-eye"></i>
                            </button>
                        </Link>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default QuestionLibrary;
