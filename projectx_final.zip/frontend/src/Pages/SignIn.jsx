const SignIn = () => {
    return (
        <div>
            <h1>SignIn</h1>
        </div>
    );
};

export default SignIn;
