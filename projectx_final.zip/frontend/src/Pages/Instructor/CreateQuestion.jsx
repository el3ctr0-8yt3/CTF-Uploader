import { useState, useEffect } from "react";
import { apiUrl } from "../../config";
import TestCaseCreator from "../../Components/TestCaseCreator";

const CreateQuestion = () => {
    const [progLangs, setProgLangs] = useState([]);
    const [testCases, setTestCases] = useState([
        {
            id: 1,
            input: "",
            output: "",
        },
    ]);

    const getProgrammingLanguages = async () => {
        const response = await fetch(`${apiUrl}/languages`);
        const data = await response.json();
        setProgLangs(data);
    };

    const createQuestionHandler = async (e) => {
        e.preventDefault();
        const questionTitle = document.getElementById("questionTitle").value;
        const questionDescription = document.getElementById(
            "questionDescription"
        ).value;
        const programmingLanguage = document.getElementById(
            "programmingLanguage"
        ).value;
        const questionScore = document.getElementById("questionScore").value;
        const memoryLimit = document.getElementById("memoryLimit").value;
        const timeLimit = document.getElementById("timeLimit").value;
        const tc = testCases;

        if (
            !questionTitle ||
            !questionDescription ||
            !programmingLanguage ||
            !questionScore ||
            !tc
        ) {
            alert("Please fill all the required fields");
            return;
        }

        const questionData = {
            title: questionTitle,
            description: questionDescription,
            language_id: programmingLanguage,
            language: progLangs.find((lang) => lang.id == programmingLanguage)
                .name,
            question_score: questionScore,
            memory_limit: memoryLimit,
            cpu_time_limit: timeLimit,
            testcase_count: tc.length,
            testcases: tc,
        };

        const response = await fetch(`${apiUrl}/question`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(questionData),
        });

        if (response.status === 201) {
            alert("Question created successfully");
            window.location.href = "/instructor/library";
        } else {
            alert("Failed to create question");
        }
    };

    useEffect(() => {
        getProgrammingLanguages();
    }, []);

    return (
        <div className="ml-8 overflow-y-scroll h-screen w-auto">
            <h1 className="text-2xl font-semibold dark:text-white my-8">
                Create New Question
            </h1>
            <form>
                <label
                    htmlFor="questionTitle"
                    className="block text-l font-semibold text-gray-400 mb-4"
                >
                    <span className="text-red-500">*</span>
                    Question Title:
                </label>
                <input
                    type="text"
                    name="questionTitle"
                    id="questionTitle"
                    className="mt-1 p-2 w-96 border border-gray-300 rounded-md mb-4"
                />
                <label
                    htmlFor="questionDescription"
                    className="block text-l font-semibold text-gray-400 my-4"
                >
                    <span className="text-red-500">*</span>
                    Question Description:
                </label>
                <textarea
                    name="questionDescription"
                    id="questionDescription"
                    className="mt-1 p-2 border border-gray-300 rounded-md w-3/4"
                    rows={10}
                    style={{ resize: "none" }}
                />
                <label
                    htmlFor="programmingLanguage"
                    className="block text-l font-semibold text-gray-400 my-4"
                >
                    <span className="text-red-500">*</span>
                    Programming Language:
                </label>
                <select
                    name="programmingLanguage"
                    id="programmingLanguage"
                    className="mt-1 p-2 border border-gray-300 rounded-md w-72"
                >
                    {progLangs.map((lang) => (
                        <option key={lang.id} value={lang.id}>
                            {lang.name}
                        </option>
                    ))}
                </select>
                <label
                    htmlFor="questionScore"
                    className="block text-l font-semibold text-gray-400 my-4"
                >
                    <span className="text-red-500">*</span>
                    Question Score:
                </label>
                <input
                    type="number"
                    name="questionScore"
                    id="questionScore"
                    className="mt-1 p-2 w-24 border border-gray-300 rounded-md mb-4"
                />
                <label
                    htmlFor="memoryLimit"
                    className="block text-l font-semibold text-gray-400 my-4"
                >
                    Memory Limit: &nbsp;
                    <span className="text-sm text-gray-600">
                        (in MB, default: 256MB)
                    </span>
                </label>
                <input
                    type="number"
                    name="memoryLimit"
                    id="memoryLimit"
                    className="mt-1 p-2 w-24 border border-gray-300 rounded-md mb-4"
                />
                <label
                    htmlFor="timeLimit"
                    className="block text-l font-semibold text-gray-400 my-4"
                >
                    Time Limit: &nbsp;
                    <span className="text-sm text-gray-600">
                        (in seconds, default: 1s)
                    </span>
                </label>
                <input
                    type="number"
                    name="timeLimit"
                    id="timeLimit"
                    className="mt-1 p-2 w-24 border border-gray-300 rounded-md mb-4"
                />
                <label
                    htmlFor="testCases"
                    className="block text-l font-semibold text-gray-400 my-4"
                >
                    <span className="text-red-500">*</span>
                    Test Cases:
                </label>
                <TestCaseCreator
                    testCases={testCases}
                    setTestCases={setTestCases}
                />

                {/* Submit Button */}
                <button
                    onClick={createQuestionHandler}
                    className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded w-48 my-10 cursor-pointer"
                >
                    Submit
                </button>
            </form>
        </div>
    );
};

export default CreateQuestion;
