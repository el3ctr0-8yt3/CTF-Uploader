import { Link } from "react-router-dom";

const Sidebar = () => {
    return (
        <aside
            id="default-sidebar"
            className="fixed top-0 left-0 z-40 w-56 h-screen transition-transform"
            aria-label="Sidebar"
        >
            <div className="h-full px-3 py-4 overflow-y-auto dark:bg-neutral-950">
                {/* Logo */}
                <Link to="/student" className="block mb-6">
                    <div className="w-36 h-16 bg-white mx-auto mt-5 mb-12"></div>
                </Link>

                {/* Links */}
                <ul className="space-y-2 font-normal text-sm">
                    <li>
                        <Link
                            to="/instructor"
                            className="flex items-center p-2 dark:text-white dark:hover:text-d-p2 dark:hover:border-d-p2 hover:border-l-4 group ml-2"
                        >
                            <i className="fa-solid fa-house" />
                            <span className="pl-2 ms-3">Dashboard</span>
                        </Link>
                    </li>
                    <li>
                        <Link
                            to="/instructor/library"
                            className="flex items-center p-2 dark:text-white dark:hover:text-d-p2 dark:hover:border-d-p2 hover:border-l-4 group ml-2"
                        >
                            <i className="fa-solid fa-layer-group" />
                            <span className="pl-2 ms-3">Question Library</span>
                        </Link>
                    </li>
                    <li>
                        <Link
                            to="/instructor/courses"
                            className="flex items-center p-2 dark:text-white dark:hover:text-d-p2 dark:hover:border-d-p2 hover:border-l-4 group ml-2"
                        >
                            <i className="fa-solid fa-book" />
                            <span className="pl-2 ms-3">Courses</span>
                        </Link>
                    </li>
                    <li>
                        <Link
                            to="/instructor/users"
                            className="flex items-center p-2 dark:text-white dark:hover:text-d-p2 dark:hover:border-d-p2 hover:border-l-4 group ml-2"
                        >
                            <i className="fa-solid fa-user" />
                            <span className="pl-2 ms-3">Users</span>
                        </Link>
                    </li>
                    <li>
                        <Link
                            to="/instructor/settings"
                            className="flex items-center p-2 dark:text-white dark:hover:text-d-p2 dark:hover:border-d-p2 hover:border-l-4 group ml-2"
                        >
                            <i className="fa-solid fa-cog" />
                            <span className="pl-2 ms-3">Settings</span>
                        </Link>
                    </li>
                </ul>
            </div>
        </aside>
    );
};

export default Sidebar;
