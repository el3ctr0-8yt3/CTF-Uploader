import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { apiUrl } from "../../config";

const QuestionLibrary = () => {
    const [questions, setQuestions] = useState([]);

    const fetchQuestions = async () => {
        const response = await fetch(`${apiUrl}/questions`);
        const data = await response.json();
        setQuestions(data);
    };

    const questionDeleteHandler = (uuid) => async () => {
        await fetch(`${apiUrl}/question/${uuid}`, {
            method: "DELETE",
        });
        fetchQuestions();
    };

    useEffect(() => {
        fetchQuestions();
    }, []);

    return (
        <div className="ml-8">
            <h1 className="text-2xl font-semibold dark:text-white my-8">
                Question Library
            </h1>

            <Link to="/instructor/createQuestion">
                <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    Create New Question
                </button>
            </Link>

            {questions.length === 0 && (
                <p className="mt-8 text-lg font-semibold text-white">
                    Library is empty. Create a new question.
                </p>
            )}

            <div className="mt-8 custom-box-width">
                {questions.map((question, index) => (
                    <div
                        key={index}
                        className="my-4 p-4 bg-dark-p2 rounded-lg font-semibold text-black flex justify-between flex-row items-center"
                    >
                        <p className="inline">{question.title}</p>
                        <button
                            className="bg-red-500 hover:bg-red-700 text-white font-bold w-10 h-10 rounded-full inline"
                            onClick={questionDeleteHandler(question.uuid)}
                        >
                            <i className="fas fa-trash"></i>
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default QuestionLibrary;
