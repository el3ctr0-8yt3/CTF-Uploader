import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";

const Instructor = () => {
    return (
        <>
            <Sidebar />
            <div className="dark:bg-d-p1 w-full h-screen fixed top-0 left-56">
                <Outlet />
            </div>
        </>
    );
};

export default Instructor;
