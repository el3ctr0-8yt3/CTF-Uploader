import { Routes, Route } from "react-router-dom";
import "./App.scss";

import SignIn from "./Pages/SignIn";

import Student from "./Pages/Student/Student";
import StudentDashboard from "./Pages/Student/Dashboard";
import StudentQuestionLibrary from "./Pages/Student/QuestionLibrary";
import Question from "./Pages/Student/Question";

import Instructor from "./Pages/Instructor/Instructor";
import InstructorDashboard from "./Pages/Instructor/Dashboard";
import InstructorQuestionLibrary from "./Pages/Instructor/QuestionLibrary";
import CreateQuestion from "./Pages/Instructor/CreateQuestion";

const App = () => {
    return (
        <div className="dark">
            <Routes index element={<SignIn />}>
                <Route path="signin" element={<SignIn />} />
                <Route path="student" element={<Student />}>
                    <Route path="" element={<StudentDashboard />} />
                    <Route
                        path="library"
                        element={<StudentQuestionLibrary />}
                    />
                    <Route path="question/:uuid" element={<Question />} />
                </Route>
                <Route path="instructor" element={<Instructor />}>
                    <Route path="" element={<InstructorDashboard />} />
                    <Route
                        path="library"
                        element={<InstructorQuestionLibrary />}
                    />
                    <Route path="createQuestion" element={<CreateQuestion />} />
                </Route>
            </Routes>
        </div>
    );
};

export default App;
