const TestCaseCreator = ({ testCases, setTestCases }) => {
    const addTestCase = () => {
        setTestCases([
            ...testCases,
            {
                id: testCases.length + 1,
                input: "",
                output: "",
            },
        ]);
    };

    const removeTestCase = () => {
        if (testCases.length > 1) {
            setTestCases(testCases.slice(0, testCases.length - 1));
        }
    };

    const testChangeHandler = (id, type) => (e) => {
        const updatedTestCases = testCases.map((testCase) => {
            if (testCase.id === id) {
                return {
                    ...testCase,
                    [type]: e.target.value,
                };
            }
            return testCase;
        });
        setTestCases(updatedTestCases);
    };

    return (
        <div>
            {testCases.map((testCase) => (
                <div
                    key={testCase.id}
                    className="grid grid-cols-2 gap-4 w-10/12 my-5"
                >
                    <textarea
                        id={"input" + testCase.id}
                        placeholder={"Input " + testCase.id}
                        className="border border-gray-300 rounded-md p-2"
                        rows={5}
                        onInput={testChangeHandler(testCase.id, "input")}
                    />
                    <textarea
                        id={"output" + testCase.id}
                        placeholder={"Output " + testCase.id}
                        className="border border-gray-300 rounded-md p-2"
                        rows={5}
                        onInput={testChangeHandler(testCase.id, "output")}
                    />
                </div>
            ))}
            <span
                onClick={addTestCase}
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded w-48 my-10 cursor-pointer text-center"
            >
                Add Test Case
            </span>
            <span
                onClick={removeTestCase}
                className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded w-48 my-10 cursor-pointer text-center ml-2"
            >
                Remove Test Case
            </span>
            <span
                onClick={() => console.log(testCases)}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-48 my-10 cursor-pointer text-center ml-2"
            >
                Log Test Cases
            </span>
        </div>
    );
};

export default TestCaseCreator;
