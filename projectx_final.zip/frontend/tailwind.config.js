/** @type {import('tailwindcss').Config} */
const defaultTheme = require("tailwindcss/defaultTheme");

export default {
    darkMode: "selector",
    content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
    theme: {
        extend: {
            fontFamily: {
                sans: ["Poppins", ...defaultTheme.fontFamily.sans],
            },
            colors: {
                d: {
                    p1: "#0c191c",
                    p2: "#2ac49e",
                    s1: "#00373b",
                    s2: "#78ffe9",
                },
            },
        },
    },
    plugins: [],
};
