const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const pg_pool = require("./db");

const createQuestion = require("./createQuestion");
const deleteQuestion = require("./deleteQuestion");
const checkSubmission = require("./checkSubmission");

const app = express();
const port = 3000;
app.use(bodyParser.json());
app.use(cors());

app.get("/languages", async (req, res) => {
    const languages = require("./languages.json");
    res.json(languages);
});

app.get("/questions", async (req, res) => {
    try {
        const { rows } = await pg_pool.query("SELECT * FROM questions");
        res.json(rows);
    } catch (error) {
        res.status(500).send("Internal Server Error");
    }
});

app.get("/question/:uuid", async (req, res) => {
    const uuid = req.params.uuid;
    try {
        const { rows } = await pg_pool.query(
            "SELECT * FROM questions WHERE uuid = $1",
            [uuid]
        );
        if (rows.length === 0) {
            res.status(404).send("Question not found");
        } else {
            res.json(rows[0]);
        }
    } catch (error) {
        res.status(500).send("Internal Server Error");
    }
});

app.delete("/question/:uuid", async (req, res) => {
    const uuid = req.params.uuid;
    try {
        const questionUUID = await deleteQuestion(uuid, pg_pool);
        res.status(200).send(`Question with UUID: ${questionUUID} deleted`);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.post("/question", async (req, res) => {
    try {
        const questionUUID = await createQuestion(req.body, pg_pool);
        res.status(201).send(`Question created with UUID: ${questionUUID}`);
    } catch (err) {
        console.log(err);
        res.status(400).send(err.message);
    }
});

app.post("/submission", async (req, res) => {
    try {
        const result = await checkSubmission(req.body, pg_pool);
        res.json(result);
    } catch (err) {
        res.status(400).send(err.message);
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
