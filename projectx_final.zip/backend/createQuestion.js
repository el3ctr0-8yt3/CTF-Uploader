const fs = require("fs");
const path = require("path");
const { v4: uuidv4 } = require("uuid");

const createQuestion = async (body, pg_pool) => {
    const uuid = uuidv4();
    body.uuid = uuid;

    console.log("Data Recieved");
    console.log(body);

    const testcases = body.testcases;
    delete body.testcases;
    const questionDir = path.join(__dirname, "questions");
    fs.writeFileSync(
        path.join(questionDir, `${uuid}.json`),
        JSON.stringify(testcases, null, 4)
    );

    console.log("Test Cases Created");

    if (body.cpu_time_limit == "") body.cpu_time_limit = null;

    if (body.memory_limit == "") body.memory_limit = null;

    const query = {
        text: `INSERT INTO questions (uuid, title, description, language_id, language, testcase_count, question_score, cpu_time_limit, memory_limit) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        values: [
            uuid,
            body.title,
            body.description,
            body.language_id,
            body.language,
            body.testcase_count,
            body.question_score,
            body.cpu_time_limit,
            body.memory_limit,
        ],
    };
    try {
        await pg_pool.query(query);
    } catch (error) {
        console.log("Error in inserting question in DB");
        throw error;
    }
    console.log("Database Updated");
    return uuid;
};

module.exports = createQuestion;
