const fs = require("fs");
const path = require("path");

const deleteQuestion = async (uuid, pg_pool) => {
    const questionDir = path.join(__dirname, "questions");
    fs.unlinkSync(path.join(questionDir, `${uuid}.json`));
    const { rows } = await pg_pool.query(
        "DELETE FROM questions WHERE uuid = $1 RETURNING uuid",
        [uuid]
    );
    if (rows.length === 0) {
        throw new Error("Question not found");
    }
    return uuid;
};

module.exports = deleteQuestion;
