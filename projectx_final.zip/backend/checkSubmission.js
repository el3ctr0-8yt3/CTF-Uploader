const fs = require("fs");
const path = require("path");
const { v4: uuidv4 } = require("uuid");
require("dotenv").config();

const checkSubmission = async (body, pg_pool) => {
    const { code, question_uuid } = body;
    const uuid = uuidv4();
    console.log("Req received!");
    console.log(body);
    const submissionDir = path.join(__dirname, "submissions");
    fs.writeFileSync(path.join(submissionDir, `${uuid}.txt`), code);
    console.log("Submission file saved");
    const { rows } = await pg_pool.query(
        "SELECT * FROM questions WHERE uuid = $1",
        [question_uuid]
    );
    if (rows.length === 0) {
        throw new Error("Question not found");
    }
    const question = rows[0];
    console.log("Question Fetched for DB");

    const language_id = question.language_id;
    const testcase_count = question.testcase_count;
    const cpu_time_limit = question.cpu_time_limit;
    const memory_limit = question.memory_limit;

    const testcases_json = fs.readFileSync(
        `questions/${question_uuid}.json`,
        "utf8"
    );
    const testcases = JSON.parse(testcases_json);
    console.log("Testcases Parsed");
    const testcase_results = [];
    for (let i = 1; i <= testcase_count; i++) {
        const input = testcases[i - 1].input;
        const output = testcases[i - 1].output;
        const judge0_query = {
            source_code: btoa(code),
            language_id,
            stdin: btoa(input),
            expected_output: btoa(output),
            cpu_time_limit,
            memory_limit,
        };
        if (judge0_query.cpu_time_limit == null) {
            delete judge0_query.cpu_time_limit;
        }
        if (judge0_query.memory_limit == null) {
            delete judge0_query.memory_limit;
        }
        console.log(judge0_query);

        const response = await fetch(
            `${process.env.JUDGE0_SERVER_URL}/submissions?base64_encoded=true`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(judge0_query),
            }
        );
        if (!response.ok) {
            throw new Error(`Failed to submit code for test case ${i}`);
        }
        const res_json = await response.json();
        const token = res_json.token;
        console.log(`Submitted code for test case ${i} with token ${token}`);
        while (true) {
            console.log("Waiting");
            await new Promise((resolve) => setTimeout(resolve, 1000));
            const status_response = await fetch(
                `${process.env.JUDGE0_SERVER_URL}/submissions/${token}?base64_encoded=true`
            );
            if (!status_response.ok) {
                throw new Error(
                    `Failed to get submission status for test case ${i}`
                );
            }
            const status_json = await status_response.json();
            if (status_json.status.id > 2) {
                status_json.testcase_id = i;
                testcase_results.push(status_json);
                console.log(`Submission test case ${i} evaluated`);
                break;
            }
        }
    }
    return testcase_results;
};

module.exports = checkSubmission;
